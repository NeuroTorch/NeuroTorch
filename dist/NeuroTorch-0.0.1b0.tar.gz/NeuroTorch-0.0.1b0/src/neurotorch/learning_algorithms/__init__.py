from .bptt import BPTT
from .eprop import Eprop
from .tbptt import TBPTT
