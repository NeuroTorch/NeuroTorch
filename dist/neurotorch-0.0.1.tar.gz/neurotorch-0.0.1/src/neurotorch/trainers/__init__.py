from .trainer import Trainer, TrainingState
from .classification import ClassificationTrainer
from .regression import RegressionTrainer
