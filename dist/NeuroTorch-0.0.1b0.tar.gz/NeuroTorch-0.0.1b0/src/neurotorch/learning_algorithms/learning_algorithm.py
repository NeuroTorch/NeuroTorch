from ..callbacks.base_callback import BaseCallback


class LearningAlgorithm(BaseCallback):
	DEFAULT_PRIORITY = BaseCallback.DEFAULT_MEDIUM_PRIORITY



