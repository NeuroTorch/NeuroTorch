__author__ = "Jérémie Gince"
# repository: https://github.com/JeremieGince/NeuroTorch


