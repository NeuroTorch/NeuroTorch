from .bptt import BPTT
from .eprop import Eprop
