# NeuroTorch
 





# Installation

## With Wheel:
0. Download the .whl file [here](https://github.com/JeremieGince/NeuroTorch/tree/main/dist/NeuroTorch-0.0.0.1-py3-none-any.whl);
1. Copy the path of this file on your computer;
2. pip install it with ``` pip install [path].whl ```

## With pip+git:
```
pip install git+https://github.com/JeremieGince/NeuroTorch
```

 ---------------------------------------------------------------------------
