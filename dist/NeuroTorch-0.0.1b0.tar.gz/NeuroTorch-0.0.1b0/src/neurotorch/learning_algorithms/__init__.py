from .bptt import BPTT
from .eprop import Eprop
from .tbptt import TBPTT
from .weak_rls import WeakRLS
from .rls import RLS
